<template>
	<div class="box">
		<img class="img" src="/img/go.jpg" alt="">
		<div class="ding">
			<p class="font">登录</p>
			<el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
			  <el-form-item label="账号" prop="pass" class="username">
			    <el-input type="password" v-model="ruleForm.pass" autocomplete="off"></el-input>
			  </el-form-item>
			  <el-form-item label="密码" prop="checkPass" class="pwd">
			    <el-input type="password" v-model="ruleForm.checkPass" autocomplete="off"></el-input>
			  </el-form-item>
			  <el-form-item class="btn">
			    <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
			  </el-form-item>
			</el-form>
		</div>
	</div>
</template>

<script>
  import * as api from "../api/index.js"
  import {mapState,mapActions,mapMutations} from 'vuex'
  export default {
    data() {
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.ruleForm.checkPass !== '') {
            this.$refs.ruleForm.validateField('checkPass');
          }
          callback();
        }
      };
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        }  else {
          callback();
        }
      };
      return {
        ruleForm: {
          pass: '',
          checkPass: '',
        },
        rules: {
          pass: [
            { validator: validatePass, trigger: 'blur' }
          ],
          checkPass: [
            { validator: validatePass2, trigger: 'blur' }
          ]
        }
      };
    },
    methods: {
		...mapActions(['getUser']),
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
			 api.Login({username:this.ruleForm.pass,pwd:this.ruleForm.checkPass}).then((res)=>{
				 if(res.data.status==200){
					 alert('登录成功')
					 this.getUser(this.ruleForm.pass)
					 sessionStorage.setItem('islogin',true)
					 this.$router.push('/Main')
				 }else{
					 alert('账号或密码不正确')
				 }
			 })
			 
			  
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>

<style>
	.font{
		font-size: 20px;
	}
	.box{
		width: 100%;
		height: 100%;
		margin: 0;
		padding: 0;
	}
	.img{
		width:100%;
		height: 100%;
		margin: 0;
		padding: 0;
	}
	.ding{
		width: 400px;
		height: 300px;
		background: white;
		position: fixed;
		left:50%;
		top:50%;
		margin-left: -200px;
		margin-top: -150px;
	}
	.demo-ruleForm{
		margin-top: 50px;
		/* margin-left: -15px; */
	}
	.username{
		width: 300px;
	}
	.pwd{
		width: 300px;
	}
	.btn{
		margin-left: -25%;
	}
</style>
