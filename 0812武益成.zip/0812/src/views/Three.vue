<template>
	<div>我是Three</div>
</template>

<script>
</script>

<style>
</style>
