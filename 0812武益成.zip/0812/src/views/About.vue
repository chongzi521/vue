<template>
	<div class="about">
		<h1>This is an about page</h1>
	</div>
</template>
<script type="text/javascript">
import {getList} from '../api'
export default {
	name: 'about',
	methods: {
	},
	
};
</script>
<style lang="less">
	
	
</style>
