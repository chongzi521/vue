<template>
	<div>
		<el-table
		 :row-class-name="tableRowClassName"
		  :data="dataInfo"
		  style="width: 100%"
		  align="center">
		  <el-table-column
		    prop="id"
		    label="id"
		    width="180">
		  </el-table-column>
		  <el-table-column
		    prop="name"
		    label="姓名"
		    width="180">
		  </el-table-column>
		  <el-table-column
		    prop="address"
		    label="地址">
		  </el-table-column>
		  <el-table-column
		    prop="count"
		    label="数量">
		  </el-table-column>
		  <el-table-column
		    prop="hospital"
		    label="医院">
		  </el-table-column>
		  <el-table-column
		    prop="age"
		    label="年龄">
		  </el-table-column>
		  <el-table-column
		    prop="sort"
		    label="排序">
		  </el-table-column>
		  <el-table-column label="操作">
		        <template slot-scope="scope">
		          <el-button
		            size="mini"
		            @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
		          <el-button
		            size="mini"
		            type="danger"
		            @click="handleDelete(scope.$index, scope.row)">删除</el-button>
		        </template>
		      </el-table-column>
		</el-table>
	</div>
	
</template>

<script>
	import {mapState} from 'vuex'
	import * as api from '../api/index'
	import axios from 'axios'
	export default{
		created(){
			api.data().then((res)=>{
				console.log(res.data.users)
				this.dataInfo=res.data.users
			})
			api.dataInfo().then((res)=>{
				console.log(res)
			})
		},
		data(){
			return{
				dataInfo:''
			}
		},
		 methods: {
			  handleEdit(index, row) {
			         console.log(index, row);
			       },
			       handleDelete(index, row) {
					   this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
					             confirmButtonText: '确定',
					             cancelButtonText: '取消',
					             type: 'warning'
					           }).then(() => {
					             this.$message({
					               type: 'success',
					               message: '删除成功!'
					             });
								 api.dele({id:row.id}).then((res)=>{
									 // console.log(res)
									 if(res.data.status==200){
										 api.data().then((res)=>{
										 	this.dataInfo=res.data.users
										 })
									 }
								 })
					           }).catch(() => {
					             this.$message({
					               type: 'info',
					               message: '已取消删除'
					             });          
					           });
			         console.log(index, row);
			       },
		      tableRowClassName({row, rowIndex}) {
		        if (rowIndex === 1) {
		          return 'warning-row';
		        } else if (rowIndex === 3) {
		          return 'success-row';
		        }
		        return '';
		      }
		    },
		computed:{
			...mapState({
				userName:state=>state.userName
			})
		}
	}
</script>

<style>
	 .el-table .warning-row {
	    background: oldlace;
	  }
	
	  .el-table .success-row {
	    background: #f0f9eb;
	  }
	.boxs{
		width: 100%;
		height: 100%;
	}
	 .el-header, .el-footer {
	    background-color: #B3C0D1;
	    color: #333;
	    text-align: center;
	    line-height: 60px;
	  }
	  .el-table__row>td{
		  text-align: center;
		  font-size: 15px;
	  }
	  .has-gutter>tr>th{
		  text-align: center;
		  font-size: 15px;
	  }
	  .el-aside {
	    background-color: #D3DCE6;
	    color: #333;
	    text-align: center;
	    line-height: 200px;
	  }
	  
	  .el-main {
	    background-color: #E9EEF3;
	    color: #333;
	    text-align: center;
	    line-height: 160px;
	  }
	  
	  body > .el-container {
	    margin-bottom: 40px;
	  }
	  
	  .el-container:nth-child(5) .el-aside,
	  .el-container:nth-child(6) .el-aside {
	    line-height: 260px;
	  }
	  
	  .el-container:nth-child(7) .el-aside {
	    line-height: 320px;
	  }
</style>