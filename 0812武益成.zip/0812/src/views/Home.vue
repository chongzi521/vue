<template>
  <div class="home">
    <!-- <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/> -->
  </div>
</template>

<script>
import axios from '../utils/request'
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  // created(){
  //   axios.get("/api/v5/getuser").then((Res)=>{
  //     console.log(Res)
  //   })
  // }
}
</script>
