<template>
	<el-container class="boxs">
	  <el-header>姓名:{{userName}}</el-header>
	  <el-container>
	    <el-aside width="200px">
			
			  <el-menu
			      default-active="2"
			      class="el-menu-vertical-demo"
			      background-color="#545c64"
			      text-color="#fff"
			      active-text-color="#ffd04b">
				  <router-link to="/main/table">
					  <el-menu-item index="2">
					    <i class="el-icon-menu"></i>
					    <span slot="title">用户表格</span>
					  </el-menu-item>
				  </router-link>
			       <router-link to="/main/echars">
			      <el-menu-item index="3">
			        <i class="el-icon-document"></i>
			        <span slot="title">Echars</span>
			      </el-menu-item>
				  </router-link>
				   <router-link to="/main/three">
			      <el-menu-item index="4">
			        <i class="el-icon-setting"></i>
			        <span slot="title">页面T</span>
			      </el-menu-item>
				    </router-link>
			    </el-menu>
			
		</el-aside>
	    <el-main>
			<router-view/>
			
		</el-main>
	  </el-container>
	</el-container>
</template>

<script>
	import {mapState} from 'vuex'
	import * as api from '../api/index'
	export default{
		created(){
			api.data().then((res)=>{
				console.log(res.data.users)
				this.dataInfo=res.data.users
			})
		},
		data(){
			return{
				dataInfo:''
			}
		},
		 methods: {
			  handleEdit(index, row) {
			         console.log(index, row);
			       },
			       handleDelete(index, row) {
			         console.log(index, row);
			       },
		      tableRowClassName({row, rowIndex}) {
		        if (rowIndex === 1) {
		          return 'warning-row';
		        } else if (rowIndex === 3) {
		          return 'success-row';
		        }
		        return '';
		      }
		    },
		computed:{
			...mapState({
				userName:state=>state.userName
			})
		}
	}
</script>

<style>
	 .el-table .warning-row {
	    background: oldlace;
	  }
	
	  .el-table .success-row {
	    background: #f0f9eb;
	  }
	.boxs{
		width: 100%;
		height: 100%;
	}
	 .el-header, .el-footer {
	    background-color: #B3C0D1;
	    color: #333;
	    text-align: center;
	    line-height: 60px;
	  }
	  .el-table__row>td{
		  text-align: center;
		  font-size: 15px;
	  }
	  .has-gutter>tr>th{
		  text-align: center;
		  font-size: 15px;
	  }
	  .el-aside {
	    background-color: #D3DCE6;
	    color: #333;
	    text-align: center;
	    line-height: 200px;
	  }
	  
	  .el-main {
	    background-color: #E9EEF3;
	    color: #333;
	    text-align: center;
	    line-height: 160px;
	  }
	  
	  body > .el-container {
	    margin-bottom: 40px;
	  }
	  
	  .el-container:nth-child(5) .el-aside,
	  .el-container:nth-child(6) .el-aside {
	    line-height: 260px;
	  }
	  
	  .el-container:nth-child(7) .el-aside {
	    line-height: 320px;
	  }
</style>
