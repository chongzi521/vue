import request from '../utils/request'

export const Reg=(params)=>{
    return request.post('/api/v1/register',params)
}

export const Login=(params)=>{
    return request.post('/api/v1/login',params)
}


export const data=()=>{
    return request.get('/api/v5/getuser')
}

export const dele=(params)=>{
    return request.post('/api/v5/deleteUser',params)
}


export const dataInfo = (data) => {
    return request.get('/bcc/index.php',data)
} 


