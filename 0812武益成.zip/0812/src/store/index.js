import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)


import createPersistedState from "vuex-persistedstate";

export default new Vuex.Store({
  state: {
	  userName:""
  },
  mutations: {
	  User(state,val){
		  state.userName=val
		  console.log(state.userName)
	  }
  },
  actions: {
	  getUser(context,val){
		  context.commit('User',val)
	  }
  },
  modules: {
  },
  plugins: [createPersistedState({
    key:'data',
    storage:window.sessionStorage
  })],
})
